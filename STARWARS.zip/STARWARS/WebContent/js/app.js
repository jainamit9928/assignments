 var underscore = angular.module('underscore', []);
underscore.factory('_', ['$window', function($window) {
  return $window._;
}]);
var app = angular.module('app', [ 'ngRoute','dataHandler', 'ui.bootstrap','myLocale','angularSpinner','underscore']).
config([ '$routeProvider', function($routeProvider) {
	
	$routeProvider.when('/', {
		redirectTo: '/login'
	}).when('/login', {
		templateUrl : 'views/common/login.html',
		controller : 'loginController',
		controllerAs: 'loginCtrl'
	}).when('/dashboard', {
		templateUrl : 'views/common/mainView.html',
		controller : 'applicationController',
		controllerAs: 'accCtrl'
	}).when('/error', {
		templateUrl : 'views/common/error.html'
	}).otherwise({
		redirectTo : '/'
	});
	


}
]);



