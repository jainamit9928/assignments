
	/**
	 * URLs for various services
	 */
	app.constant('SERVICES_CONSTANTS', {
		url: 'http://swapi.co/api'
		
	});
	
	
	

		