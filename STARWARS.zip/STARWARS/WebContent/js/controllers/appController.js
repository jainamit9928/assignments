// this controller is for dashboard page
// using pagination directive ,search filter,modal,spinere service

app.controller('applicationController', [
		'$scope',
		'sharedModels',
		'$timeout',
		'$modal',
		'$location',
		'$locale',
		'usSpinnerService',
		function($scope,sharedModels,$timeout,$modal, $location,
				$locale,usSpinnerService) {
            
			
            
       
			var init = function() {
				
				$scope.appData = [];
				$scope.loaded = false;
				$scope.loadData();
				$scope.profileData = {};
				
				
			};

			$scope.open = function() {
				$modal.open({
					animation : true,
					templateUrl : 'views/common/profileForm.html',
					controller : 'modalController',
					backdrop : 'static',
					backdropClass : 'modal-backdrop h-full'

				});
			};

			$scope.loadData = function() {

		        usSpinnerService.spin('spinner-1');
				var def = sharedModels.loadData();
				def.then(function(data) {
					 usSpinnerService.stop('spinner-1');
					$scope.appData = data.results;
					if (!$scope.appData.length > 0) {
						$location.path('/error');
					} else {
						$scope.paginatedata($scope.appData, $scope.pageSize);
					}
				}, function(error) {
					 usSpinnerService.stop('spinner-1');
					$location.path('/error');
				});

			};

			init();
			
			

			$scope.findData = function(i) {
				console.log("data in find"+$scope.appData);
				var find = _.findWhere($scope.appData, {
					id : i
				});
				return find;
			};

			

			

		} ]);

