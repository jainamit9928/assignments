// this controller is for login page
// using forms,modal,spinere service

app.controller('loginController', [
		'$scope',
		'sharedModels',
		'$route',
		'$location',
		'sessionModels',
		'$modal',
		'$timeout',
		'_',
		
		function($scope,sharedModels, $route, $location,
				sessionModels, $modal, $timeout,underscore) {

		

			
			$scope.submits = function() {
				document.getElementById("alrt").style.display="none";
				sharedModels.checkLogin().then(function(data) {
					console.log("checking login" + $scope.formData);
					//var obj={"name":$scope.formData.userId,"birth_year":$scope.formData.password}
					//var status=_.findWhere(data.results, obj);

					var peopleArray=data.results;
					var status=false;
					for(i=0; i<peopleArray.length; i++){
						var obj=peopleArray[i];
						if(!status && obj.name == $scope.formData.userId && obj.birth_year == $scope.formData.password ){
							status=true;
						}
					}
					if (status) {

						
						var modalInstance = $modal.open({
							animation : true,
							templateUrl : 'views/common/thanks.html',
							backdrop : 'static',
							backdropClass : 'modal-backdrop h-full'

						});

						$timeout(function() {
							modalInstance.close();
							$location.path('/dashboard');
						}, 2000);
						
					}
					else{
					document.getElementById("alrt").style.display="block";	
					}
				}, function error(error) {
					
					var modalInstance = $modal.open({
						animation : true,
						templateUrl : 'views/common/thanks.html',
						backdrop : 'static',
						backdropClass : 'modal-backdrop h-full',
						
					});

					$timeout(function() {
						modalInstance.close();
					}, 2000);

				});

			};

		} ]);