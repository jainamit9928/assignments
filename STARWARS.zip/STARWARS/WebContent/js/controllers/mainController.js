app.controller('MainController', [ '$scope', '$location',
		function($scope, $location) {
			// sessionModels.checkError();
			$scope.backToHome = function() {
				$location.path('/login');

			};

		} ]);