
app.directive('logoSection', function() {

	return {
		restrict : 'E',
		templateUrl : 'views/common/logo.html'
	};

});

/*
 * Code for Autofill for error handling
 * 
 * App.directive("required", ['$timeout', function ($timeout) {
 return {
 require: 'ngModel',
 link: function (scope, element, attrs, ngModel) {
 element.after('<div class="required-tick">*</div>');

 // listen for pertinent events to trigger input on form element
 // use timeout to ensure val is populated before triggering 'input'
 // ** 'change' event fires for Chrome
 // ** 'DOMAttrModified' fires for Firefox 22.0
 // ** 'keydown' for Safari  6.0.1
 // ** 'propertychang' for IE
 element.on('change.autofill DOMAttrModified.autofill keydown.autofill propertychange.autofill', function (e) {
 $timeout( function () {
 if (element.val() !== '') {
 element.trigger('input');
 }
 }, 0);
 });

 }
 }
 }]);*/


app.directive('navSection', function() {

	return {
		restrict : 'E',
		templateUrl : 'views/common/nav.html'

	};

});

app.directive('gridheader', [ '$log', '$filter', 'providedValue',
		function($log, $filter, providedValue) {

			return {
				restrict : 'E',
				templateUrl : 'views/common/header.html',
			};
		}	
	]);

app.directive('grid', [ '$log', '$filter','providedValue', function($log, $filter,providedValue) {
	return {
		restrict : 'E',
		templateUrl : 'views/common/grid.html',
		controller : "applicationController",
	    link : function($scope, el, attrs) {
				
				

			}

		};
	

} ]);

app.directive('apppagination', ['$log',
                                function($log) {
    return {
        restrict: 'E',
        templateUrl: 'views/common/pagination.html',

        controller: function($scope) {

        },

        link: function($scope, el, attrs) {



            $scope.setPage = function(p) {

              
           	 $scope.curPage = p;


            };





        }
    };

}
]);

app.directive('filter', [
		'$log',
		'$filter',
		'$window',
		function($log, $filter, $window) {

			return {
				restrict : 'E',

				templateUrl : 'views/common/filter.html',
				controller : "applicationController",

				link : function($scope, el, attrs) {

					$scope.pageSize = 5;
					$scope.curPage = 0;
					$scope.sessionDetails = [];

					$scope.paginatedata = function(data, size) {

						var clone = $scope.cloneData($scope.appData);
						var arraySplice = [];
						while (data.length > 0) {
							arraySplice.push(data.splice(0, size));
							//alert("arraySplice"+arraySplice);
						}

						$scope.sessionDetails = arraySplice;
						$scope.appData = clone;
						console.log("in directive" + $scope.appData
								+ $scope.sessionDetails);

					};

					$scope.$watch('searchText', function(val) {

						$scope.filteredData = $filter('filter')($scope.appData,
								val);

						if ($scope.filteredData !== undefined) {
							$scope.paginatedata($scope.filteredData,
									$scope.pageSize);
						}

					});

					$scope.cloneData = function(data) {
						var clone = _.clone(data);

						return clone;
					};

				}
			};

		}

]);

/*app.directive('spinner', [ function() {
	return {
		restrict : 'E',
		template : [ '<div ng-show="showSpinner">', '<div id="resultLoading">',
				'<div class="loader dark"></div>', '<div class="bg"></div>',
				'</div></div>' ].join(''),
		replace : true,
		scope : {
			id : '@',
			group : '@?',
			showSpinner : '@?',
			onRegisterComplete : '&?'
		},
		controller : [ '$scope', '$attrs', 'spinnerService',
				function($scope, $attrs, spinnerService) {
					// Register the spinner with the spinner service.
					spinnerService._register($scope);

					// Invoke the onRegisterComplete expression, if any.
					// Expose the spinner service for easy access.
					$scope.onRegisterComplete({
						$spinnerService : spinnerService
					});
				} ],
		link : function(scope, elem, attrs) {
			// Check for pre-defined size aliases and set pixel width accordingly.
			if (attrs.hasOwnProperty('size')) {
			  attrs.size = attrs.size.toLowerCase();
			}
			switch (attrs.size) {
			  case 'tiny':
			    scope.spinnerSize = '15px';
			    break;
			  case 'small':
			    scope.spinnerSize = '25px';
			    break;
			  case 'medium':
			    scope.spinnerSize = '35px';
			    break;
			  case 'large':
			    scope.spinnerSize = '64px';
			    break;
			  default:
			    scope.spinnerSize = '50px';
			    break;
			}
		}
	};
} ]);*/
