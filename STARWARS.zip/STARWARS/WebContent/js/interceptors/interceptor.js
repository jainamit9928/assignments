/**
 * Type: factory
 * Name: timerResetInterceptor 
 **/
app.factory('myHttpInterceptor',
		[ '$q', function($q, dependency1, dependency2) {
			var s = 0;
			return {
				// optional method
				'request' : function(config) {
					// do something on success
					console.log("Request IN INTERCEPTOR");
					s = (new Date());
					return config || $q.when(config);
				},

				// optional method
				'requestError' : function(rejection) {
					// do something on error
					if (canRecover(rejection)) {
						return responseOrNewPromise;
					}
					return $q.reject(rejection);
				},

				// optional method
				'response' : function(response) {
					// do something on success
					console.log("Responce IN INTERCEPTOR");
					response.duration = (new Date()) - s;
					return response || $q.when(response);
				},

				// optional method
				'responseError' : function(rejection) {

					return $q.reject(rejection);
				}
			};
		} ]).config([ '$httpProvider', function($httpProvider) {
				$httpProvider.interceptors.push('myHttpInterceptor');
} ]);
