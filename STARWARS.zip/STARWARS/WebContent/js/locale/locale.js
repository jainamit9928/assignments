angular.module("myLocale", [], [ "$provide", function($provide) {
	$provide.value("providedValue", {
		userId : "User Id",
		id : "Id",
		title : "Title",
		body : "Body"
	});
} ]);