(function() {

	var app = angular.module('dataHandler', []);

	app.service('sharedModels', [ '$http', '$q', '$location',
			'SERVICES_CONSTANTS', '$timeout',
			function($http, $q, $location, SERVICES_CONSTANTS, $timeout) {


				this.loadData = function() {
					var deferred = $q.defer();
					var path="/planets"
					$http.get(SERVICES_CONSTANTS.url+path).success(function(data) {
						console.log("in service1" + data);
						$timeout(function() {
							deferred.resolve(data);
						}, 2000);
					}).error(function(error) {
						deferred.reject(error);
					});

					return deferred.promise;
				};
				
				this.checkLogin = function() {

					console.log("in services");
					var defered = $q.defer();
					var path="/people"
					$http({
						method : "GET",
						url : SERVICES_CONSTANTS.url+path
					
					}).success(function(result) {
						console.log("in add result is" + result);
						defered.resolve(result);
					}).error(function error(error) {
						defered.reject(error);
					});

					return defered.promise;
				};

			} ]);
		
		
})();