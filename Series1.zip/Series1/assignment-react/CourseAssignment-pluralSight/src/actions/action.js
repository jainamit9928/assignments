import * as types from '../constants/constants.js'

export const incrementFunction = () => ({type:types.INCREMENT_COUNTER}) ;
export const decrementFunction = () => ({type:types.DECREMENT_COUNTER}) ;
export const resetFunction = () => ({type:types.RESET_COUNTER}) ;
  

