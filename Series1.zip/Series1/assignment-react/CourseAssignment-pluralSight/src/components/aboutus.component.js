import React from 'react';

const AboutUs = () => {
    return(
        <div className="row col-md-12">
        This is a About Us page

        </div>
    )
}

export default AboutUs;