import React from 'react';
import ReactDOM from 'react-dom'
class ContactUs extends React.Component {
  constructor(props) {
    super(props);
   this.match = this.props.match
   this.divStyle = {
           background:"transparent",
           width:"900px",
           height:"600px",
        

        }
  }
submitForm(){
        console.log(this.refs);
     alert(this.refs);
    
    }
  render(){
     return(
  
<div className="container">
<div className="row">
  <div className="col-md-6 col-md-offset-3 divStyle">
            <div className="well well-sm">
                     <form ref="contact-form" className="form-horizontal" >
  
                                 <legend className="text-center">Contact us</legend>

        

        <div id="form-container">

         
          <div className="form-group">
            <label className="col-md-3 control-label" htmlFor="name">Name</label>
            <div className="col-md-9">
              <input ref="name" name="name" type="text" placeholder="Your name" className="form-control" required></input>
            </div>
          </div>

         
          
          <div className="form-group">
            <div className="col-md-12 text-right" id="spin-area">
            </div>
          </div>
        </div>

         
          <div className="form-group">
            <label className="col-md-3 control-label" >Your E-mail</label>
            <div className="col-md-9">
              <input ref="email" name="email" type="text" placeholder="Your email" className="form-control" required/>
            </div>
          </div>

          
          <div className="form-group">
            <label className="col-md-3 control-label" >Your message</label>
            <div className="col-md-9">
              <textarea className="form-control" ref="message" name="message" placeholder="Please enter your message here..." rows="5" required></textarea>
            </div>
          </div>

         
          <div className="form-group">
            <div className="col-md-12 text-right" id="spin-area">
              <button type="submit" className="btn btn-primary btn-lg" onClick={this.submitForm.bind(this)}>Submit</button>
            </div>
          </div>
    
      </form>
    

    </div>
    </div>
    </div>
    </div>



)
  }
}

ContactUs.defaultProps ={
  
}
ContactUs.propTypes ={
    
}

export default ContactUs
