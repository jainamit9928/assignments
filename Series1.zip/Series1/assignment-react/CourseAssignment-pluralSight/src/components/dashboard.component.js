import React from 'react'
import {Route,Link } from 'react-router-dom'
import Counter from './counter.component'

class Dashboard extends React.Component {
  constructor(props) {
    super(props);
   this.match = this.props.match
   this.divStyle = {
           background:"transparent",
           width:"900px",
           height:"600px",
        

        }
        this.state ={
            counter:0
        }
  }
onIncrement(){
this.setState({
    counter:this.state.counter+1
})
}

onDecrement(){
this.setState({
    counter:this.state.counter - 1
})
}

  render(){
      return(
<section style={this.divStyle}>
  <Route exact path={this.props.match.url} render = { () => ( <h3>Please select a page</h3>) } />
    <div className="row">
        <div className="col-md-6">
           
            
                        
                       
             <Link className ="btn btn-success" to={`${this.props.match.url}/counter`} >
               Counter
                </Link>
           
             
            
        </div>
      
     </div>
      <div className="col-md-6">
         <Route  path={`${this.props.match.url}/:paramId`} component={() => (Counter) } />
        </div>
 
</section>
      )
  }
}



export default Dashboard