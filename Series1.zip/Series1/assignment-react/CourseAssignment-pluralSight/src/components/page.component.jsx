import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom'
import Logo from './header.component'
import Nav from './nav.component'
import Footer from './footer.component'
import ContactUs from './contact.component'
import AboutUs from './aboutus.component'
import Dashboard from './dashboard.component'

export default class Page extends React.Component {

    render() {

        return (<Router>
            <div >

                <div className="row">
                    <div className="col-md-12">
                        <Logo title="Welcome to Saxo" />
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-6">

                    </div>
                    <div className="col-md-12">

                        <Nav />

                    </div>
                </div>

                <main className="container" style={this.divStyle}>

                    <div className="col-md-12">
                        <Route path="/dashboard" component={Dashboard} />
                        <Route path="/contact" component={ContactUs} />
                        <Route path="/aboutus" component={AboutUs} />
                    </div>
                </main>

                <div className="container">
                    <Footer />
                </div>
            </div>


        </Router>)
    }
}


export class MyPage extends React.Component{
    render(){
        return (<Page/>)
    }
}
