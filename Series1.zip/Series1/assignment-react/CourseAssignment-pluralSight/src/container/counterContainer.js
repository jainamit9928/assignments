import React, { Component } from 'react'
import PropTypes from 'prop-types'
import * as stateActions from '../actions/action'
import {connect} from 'react-redux'
import UICounter from '../components/counter.component'

const mapStateToProps = state => {
  var data ={
    counter:state.state.counter
  }
  return data;
}

const mapDispatchToProps = (dispatch, ownProps) => (
  {
    increase : () => dispatch(stateActions.incrementFunction()),
    decrease : () =>dispatch(stateActions.decrementFunction())
  }
)

class Counter extends React.Component{
  constructor(props){
    super(props);
    console.log(this.props)
  }
    render(){
        return(
           <UICounter counter ={this.props.counter} increase ={this.props.increase} decrease ={this.props.decrease} />
        )
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(Counter);