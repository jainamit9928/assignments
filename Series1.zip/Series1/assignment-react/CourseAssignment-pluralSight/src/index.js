import React from 'react';
import ReactDOM from 'react-dom'
import {MyPage} from './components/page.component'
import {Provider} from 'react-redux'
import {combineReducers ,createStore,applyMiddleware} from 'redux'
import counter from './reducers/reducer'
import Counter from './container/counterContainer'
import {logger , crashReporter} from './middleware/middleware'
//import App from './containers/App';
const reducers = combineReducers({
    state:counter
})
const store = createStore(reducers,applyMiddleware(logger,crashReporter));

ReactDOM.render(
    <Provider store={store}>
        <Counter />
    </Provider>
,document.getElementById("container")
    );
