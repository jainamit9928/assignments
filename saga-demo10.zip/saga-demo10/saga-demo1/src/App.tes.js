import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import Counter from './container/counterContainer'
/*
it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(<Counter status ={true} courses ={[1,2,3]} loadCourses ={() => {console.log("test")}}/>, div);
});
*/

it("sum should return sum",() =>{
    var counter = new Counter();
    var sum = counter.sum(1,2);
    expect(sum).toBe(3)
});