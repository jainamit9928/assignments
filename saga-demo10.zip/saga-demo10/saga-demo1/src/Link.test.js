// Link.react-test.js
import React from 'react';
import Link from './components/Link';
import renderer from 'react-test-renderer';

test('Link changes the class when hovered', () => {
  const component = renderer.create(
    <Link page="http://www.facebook.com">Facebook</Link>
  );
  let tree1 = component.toJSON();
  expect(tree1).toMatchSnapshot();

  // manually trigger the callback
  tree1.props.onMouseEnter();
  // re-rendering
  let tree2 = component.toJSON();
  expect(tree2).toMatchSnapshot();

  // manually trigger the callback
  tree2.props.onMouseLeave();
  // re-rendering
  let tree3 = component.toJSON();
  expect(tree3).toMatchSnapshot();
 expect(tree3).toEqual(tree1);
});