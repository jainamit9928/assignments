import * as types from '../constants/constants.js'

export const incrementFunction = () => ({type:types.INCREMENT_COUNTER}) ;
export const decrementFunction = () => ({type:types.DECREMENT_COUNTER}) ;
export const resetFunction = () => ({type:types.RESET_COUNTER}) ;
export const loadDataSuccess = (data) => ({type:types.LOAD_DATA_SUCCESS,data}) 
export const loadDataFailure = (message) => ({type:types.LOAD_DATA_FAILURE,message})   
export const showLoading = (status) => ({type:types.SHOW_LOADING,status})
export const loadData = () =>({type:types.LOAD_DATA_ASYNC})
export  const showCongrats = () => ({type: types.SHOW_CONGRATULATION});
