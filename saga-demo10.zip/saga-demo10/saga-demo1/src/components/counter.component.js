import React, { Component } from 'react'
import PropTypes from 'prop-types'
import * as stateActions from '../actions/action'
const UICounter = (props) => (
<div className="col-md-12 col-md-offset-3 " >
        
            <div className="well well-sm col-md-12">
            {props.status && <div >Loading....</div> }
            {props.congrats && alert("congrats")}
            {props.courses && props.courses.map((course,index) =>(<div key ={index} className="col-md-12 panel">{course.title}</div>) )}
              <div className="col-md-6"><button type="submit" className="btn btn-primary" onClick ={props.loadCourses}>Load Data</button></div>
        
      </div>
      </div>
)
 




export default UICounter;