import React from 'react';
const Logo = (props) =>(
 <header>  
<div className="">
<img src="../assets/images/logo.jpg" width="200" height="100" alt={props.title}/>
<h3>{props.title}</h3>
</div>
</header>
)
export default Logo;
