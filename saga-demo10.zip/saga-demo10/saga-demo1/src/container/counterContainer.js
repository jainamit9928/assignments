import React, { Component } from 'react'
import PropTypes from 'prop-types'
import * as stateActions from '../actions/action'
import {connect} from 'react-redux'
import UICounter from '../components/counter.component'

const mapStateToProps = state => {
  var data ={
    courses:state.courses
  }
  console.log(data)
  return data;
}

const mapDispatchToProps = (dispatch, ownProps) => (
  {
    loadCourses : () => dispatch(stateActions.loadData()),
   
  }
)

class Counter extends React.Component{
  constructor(props){
    super(props);
    console.log(this.props)
  }

  sum(x,y) {
    return x+y;
  }

  
    render(){
        return(
           <UICounter congrats = {this.props.courses.congrats} status ={this.props.courses.status} courses ={this.props.courses.data} loadCourses ={this.props.loadCourses} />
        )
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(Counter);

//for test cases
//export default Counter;