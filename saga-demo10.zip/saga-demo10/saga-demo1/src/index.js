import React from 'react';
import ReactDOM from 'react-dom'
import {MyPage} from './components/page.component'
import {Provider} from 'react-redux'
import {combineReducers ,createStore,applyMiddleware} from 'redux'
import counter from './reducers/reducer'
import courses from './reducers/mockApiReducer'
import Counter from './container/counterContainer'
import {logger , crashReporter} from './middleware/middleware'
import rootSaga from "./sagas/saga.js";
import createSagaMiddleware from "redux-saga";
import CheckboxWithLabel from './components/CheckboxWithLabel';
//import App from './containers/App';
const sagaMiddleware = createSagaMiddleware();
const reducers = combineReducers({
   courses
})
const store = createStore(reducers,applyMiddleware(sagaMiddleware));
sagaMiddleware.run(rootSaga);
ReactDOM.render(
    <Provider store={store}>
        <Counter />
    </Provider>
,document.getElementById("container")
    );


//for running test cases
//ReactDOM.render(<CheckboxWithLabel />, document.getElementById('root'));