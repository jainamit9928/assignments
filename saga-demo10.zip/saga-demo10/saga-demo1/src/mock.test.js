import courseApi from './api/mockCourseApi'

class MyClass {
    sum(a,b){
        console.log("SUM")
        return this.serviceCall(a,b)
    }
    serviceCall(a,b){
    return a+b
    }
}

it.only('passes through non-function action',() => {
let obj = new MyClass();
MyClass.prototype.serivceCall = jest.fn(() => 3);
let result = obj.sum(1,2);
expect(result).toBe(3);
})