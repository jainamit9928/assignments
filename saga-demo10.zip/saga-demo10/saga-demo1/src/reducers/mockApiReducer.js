import * as actionTypes from '../constants/constants.js'

this.intialState = {
    data: [],
    status: false,
    message: "",
    congrats:false
}


const courses = (state = this.intialState, action) => {
    
    switch (action.type) {
        case actionTypes.LOAD_DATA_SUCCESS:
            var output = Object.assign({}, state, { data: action.data, status: false });
            return output;
        case actionTypes.LOAD_DATA_FAILURE:
            return Object.assign({}, state, { message: action.message, status: false })
        case actionTypes.SHOW_LOADING:
            return Object.assign({}, state, { status: action.status })
        case actionTypes.SHOW_CONGRATULATION:
       return Object.assign({}, state, { congrats:true })
        default:
            return state;
    }
}

export default courses