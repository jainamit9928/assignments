
import * as actionTypes from '../constants/constants.js'
this.intialState ={
    counter:0
}
 const counter = (state = this.intialState,action) =>{
    switch(action.type){
        case actionTypes.INCREMENT_COUNTER:
        console.log(state);
        return Object.assign({},...state,{counter:state.counter + 1});
        case actionTypes.DECREMENT_COUNTER:
        console.log(state);
        return Object.assign({},...state,{counter:state.counter - 1});
        case actionTypes.RESET_COUNTER:
        console.log(state);
        return Object.assign({},...state,{counter:0})
        default:
        return state;
    }
}

export default counter