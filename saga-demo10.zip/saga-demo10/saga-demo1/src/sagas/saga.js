import React from "react";
import { delay } from "redux-saga";
import { call, put, takeEvery, all, race, take, select } from "redux-saga/effects";
import * as actionTypes from "../constants/constants.js"
import courseApi from '../api/mockCourseApi'
import authorApi from '../api/mockAuthorApi'
import * as actions from '../actions/action'

// const courseData = [
//   {
//     id: "react-flux-building-applications",
//     title: "Building Applications in React and Flux",
//     watchHref: "http://www.pluralsight.com/courses/react-flux-building-applications",
//     authorId: "cory-house",
//     length: "5:08",
//     category: "JavaScript"
//   },
//   {
//     id: "clean-code",
//     title: "Clean Code: Writing Code for Humans",
//     watchHref: "http://www.pluralsight.com/courses/writing-clean-code-humans",
//     authorId: "cory-house",
//     length: "3:10",
//     category: "Software Practices"
//   }
// ];
// function getAllCourses(){
// setTimeout(function(){
//   return courseData
// },3000)
// }

function RaceAll() {
  setTimeout(function () {
    console.log("race All also resolved")
    return "data from race all"
  }, 5000)
}

export function* helloSaga() {
  console.log("From Saga");
}


function* raceData() {
  const {coursesR,authorsR} = yield race({
    coursesR: call(courseApi.getAllCourses),
    authorsR: call(authorApi.getAllAuthors)
  })
  console.log("in generator raceDATA",coursesR,"--",authorsR)
  return {coursesR,authorsR}
}

function* allData() {
  const {courses,authors} = yield all({
    courses:call(courseApi.getAllCourses),
    authors:call(authorApi.getAllAuthors)
})
  return {courses,authors}
}


export function* loadCourses() {


  try {
    yield put(actions.showLoading(true))
    var data = yield call(courseApi.getAllCourses)

    //yielded all requests
    const {courses,authors} = yield* allData()
    console.log("all authors", authors)
    console.log("all courses", courses)

    const {coursesR,authorsR} = yield* raceData()
    console.log("all authorsR", authorsR)
    console.log("all coursesR", coursesR)

    // if data then sucesds action
    yield put(actions.loadDataSuccess(data))


  } catch (error) {
    yield put(actions.loadDataFailure("data fetching failed"))
  }
  finally {
    yield put(actions.showLoading(false))
  }

}

//backgroundTask
function* watchAndLog() {
  while (true) {
    const action = yield take('*')
    const state = yield select()

    console.log('action from saga', action)
    console.log('state after saga', state)
  }
}

function* watchStartBackgroundTask() {
  while (true) {
    yield take('*')
    yield race({
      task: call(watchAndLog),
      cancel: take('CANCEL_TASK')
    })
  }
}





function* watchFirstThreeTodosCreation() {
  for (let i = 0; i < 3; i++) {
    const action = yield take('LOAD_DATA_SUCCESS')
    console.log("in watchFirstThree", action)
    //yield take('LOAD_DATA_SUCCESS')
    //yield take('LOAD_DATA_SUCCESS')
    //yield take('LOAD_DATA_SUCCESS')
  }
  yield put({ type: 'SHOW_CONGRATULATION' })
}

export function* watchIncrementAsync() {
  console.log("in wathc")
  yield takeEvery(actionTypes.LOAD_DATA_ASYNC, loadCourses)
}
export default function* rootSaga() {
  yield all([helloSaga(), watchIncrementAsync(), watchFirstThreeTodosCreation(), watchStartBackgroundTask()])
}