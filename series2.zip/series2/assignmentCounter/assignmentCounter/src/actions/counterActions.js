import * as types from '../constants/constants.js'

export const increase = () => ({type:types.INCREMENT_COUNTER}) ;
export const decrease = () => ({type:types.DECREMENT_COUNTER}) ;
export const resetFunction = () => ({type:types.RESET_COUNTER}) ;

  

