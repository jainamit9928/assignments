import * as types from '../constants/constants.js'
export const addCourse = (course) => ({type:types.ADD_COURSE,course:course})