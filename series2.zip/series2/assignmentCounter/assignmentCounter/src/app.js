import React from 'react'
import ReactDOM from 'react-dom'
import RouterComponent from './router'
import {Provider} from 'react-redux'
import {MyPage} from './components/page.component'
import {combineReducers ,createStore,applyMiddleware} from 'redux'
import counter from './reducers/counterReducer'
import Counter from './container/counterContainer'
import Courses from './container/courseContainer'
import {logger , crashReporter} from './middleware/middleware'
import courses from './reducers/courseReducer'
const reducers = combineReducers({
  counter ,
   courses
})
const store = createStore(reducers,applyMiddleware(logger,crashReporter));
const App = () =>( <Provider store={store}>
   <RouterComponent />
  </Provider>)

  export default App
  