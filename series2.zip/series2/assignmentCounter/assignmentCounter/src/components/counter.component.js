import React, { Component } from 'react'
import PropTypes from 'prop-types'

const UICounter = (props) => (
<div className="col-md-6 col-md-offset-3 " >
        
            <div className="well well-sm">
     
        Clicked: {props.counter} 
        {' '}
        <button className="btn btn-success" onClick={props.increase}>
          +
        </button>
        {' '}
        <button className="btn btn-success" onClick={props.decrease}>
          -
        </button>
        
      </div>
      </div>
)
 




export default UICounter;