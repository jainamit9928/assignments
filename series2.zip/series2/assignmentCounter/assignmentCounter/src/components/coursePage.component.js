import React from 'react'
import ReactDOM from 'react-dom'

const UICourses = ({onAddCourse,courses}) => {
     let input;
    return(
        <div>
           { courses && courses.map((course,index) => (<div key={index}>{course.course}</div> )) }
        <input type="text" ref={node => {
                input = node
            }} />
            <button type="submit" onClick = { () => { onAddCourse(input.value); input.value = ""; } } >Add Course</button>
                </div>
    )
}



export default UICourses;