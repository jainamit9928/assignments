import React from 'react';
const Footer = () =>{
    let divStyle ={
        width:"900px",
        height:"80px",
        marginTop:"300px",
        borderTop:"1px solid green"
    }
    return(
    <footer style={divStyle}>
        <div className="container">
            <div className="row">
                <div className="col-md-6">
                    
                        <p> - by Refsnes Data. All Rights Reserved.</p>
                        <p>All content and graphics on this web site are the property of the company Refsnes Data.</p>
                   
                </div>
                <div className="col-md-6">
                    <video width="300" controls>
                         <source src="../assets/video/video.mp4" type="video/mp4" />
                        
                    </video>
                </div>

            </div>

        </div>
       



    </footer>
    )
}
export default Footer