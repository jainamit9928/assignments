import React from 'react';
import { Link } from 'react-router-dom'
const Nav = (props) => {
    return(
                     <nav className="navbar navbar-inverse">
                            <div className="container-fluid">
                                    
                                    <ul className="nav navbar-nav">
                                      <li><Link to="/dashboard" >DashBoard</Link></li>
                                    
                                       
                                    <li><Link to="/aboutus">About Us</Link></li>
                                    <li><Link to="/contact" >Contact</Link></li>
                                    </ul>
                             </div>
                        </nav>
    )
}

export default Nav;