import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom'
import Logo from './header.component'
import Nav from './nav.component'
import Footer from './footer.component'
import ContactUs from './contact.component'
import AboutUs from './aboutus.component'
import Dashboard from './dashboard.component'

export default class Page extends React.Component {

    render() {

        return (<Router>
            

        </Router>)
    }
}


export class MyPage extends React.Component{
    render(){
        return (<Page/>)
    }
}
