import React, { Component } from 'react'
import PropTypes from 'prop-types'
import * as counterActions from '../actions/counterActions'
import {connect} from 'react-redux'
import UICounter from '../components/counter.component'
import {bindActionCreators} from 'redux'

const mapStateToProps = state => {
  
  return {
    count:state.counter.counter
  }
}

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
       actions:bindActionCreators(counterActions,dispatch)
    }
  
}

class Counter extends React.Component{
  constructor(props){
    super(props);
    console.log(this.props)
  }
    render(){
        return(
           <UICounter counter ={this.props.count} increase ={this.props.actions.increase} decrease ={this.props.actions.decrease} />
        )
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(Counter);