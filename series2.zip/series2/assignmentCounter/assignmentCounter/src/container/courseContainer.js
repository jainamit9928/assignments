import React, { Component } from 'react'
import PropTypes from 'prop-types'
import * as courseActions from '../actions/courseActions'
import { connect } from 'react-redux'
import UICourses from '../components/coursePage.component'
import {bindActionCreators} from 'redux'
class Courses extends React.Component {
    constructor(props) {
        super(props)
    }

    render() {
        return (
            <UICourses onAddCourse={this.props.actions.addCourse} courses={this.props.courses} />
        )
    }

}

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
       actions:bindActionCreators(courseActions,dispatch)
    }
}
const mapStateToProps = state => {
    return {
        courses: state.courses
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Courses);
