import * as actionTypes from '../constants/constants.js'

const courses = (state = [],action) => {
switch(action.type){
    case actionTypes.ADD_COURSE:
    return [...state,{course:action.course}]
    default:
    return state;
}
}

export default courses;