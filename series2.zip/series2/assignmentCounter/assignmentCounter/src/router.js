import React from 'react';
import { DefaultRoute ,BrowserRouter as Router, Route,Switch } from 'react-router-dom'
import Logo from './components/header.component'
import Nav from './components/nav.component'
import Footer from './components/footer.component'
import ContactUs from './components/contact.component'
import AboutUs from './components/aboutus.component'
import Dashboard from './components/dashboard.component'
import Courses from './container/courseContainer'


const RouterComponent =() => (

    
<div >

                <div className="row">
                    <div className="col-md-12">
                        <Logo title="Welcome to Saxo" />
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-6">

                    </div>
                    <div className="col-md-12">

                        <Nav />

                    </div>
                </div>

                <main className="container" style={this.divStyle}>

                    <div className="col-md-12">
                        
                    <Switch>
                        {/*  <Route  path="/" component={Courses} /> */}
                        <Route exact path="/" component={Courses} />
                        <Route  path="/dashboard" component={Dashboard} />
                        <Route path="/contact" component={ContactUs} />
                        <Route path="/aboutus" component={AboutUs} />
                    </Switch>
                        
                    </div>
                </main>

                <div className="container">
                    <Footer />
                </div>
            </div>
    
);
export default RouterComponent