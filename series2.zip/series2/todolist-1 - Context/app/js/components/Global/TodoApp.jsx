import React from 'react';
import VisibleTodosList from './visibleTodoList';
import Filters from './Filters';
import AddTodo from './AddTodo';

const TodoApp = () => ( 
        <div>
            <AddTodo/>
            <VisibleTodosList/>
            <Filters/>
        </div>
    );
    



export default TodoApp;
