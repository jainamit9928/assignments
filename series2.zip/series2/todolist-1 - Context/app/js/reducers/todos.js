import _ from 'lodash';
import { v4 } from 'node-uuid';

const todo = (state, action) => {
    switch (action.type) {
        case 'ADD_TODO':
            return {
                id: v4(),
                text: action.text,
                completed: false,
            };

        case 'TOGGLE_TODO':

            if (state.id !== action.id) {
                return state;
            }

            return {
                id: state.id,
                text: state.text,
                completed: !state.completed,
            };

        default:
            return state;
    }
};

const todos = (state = [], action) => {
    switch (action.type) {
        case 'ADD_TODO':
            return [
                ...state,
                todo(undefined, action),
            ];

        case 'REMOVE_TODO':
            return _.reject(state, function(todox) {
                return todox.id === action.id;
            });

        case 'TOGGLE_TODO':
            return _.map(state, function(todox) {
                return todo(todox, action);
            });

        default:
            return state;
    }

};

export default todos;
