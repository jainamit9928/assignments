import { createStore } from 'redux';
import todoApp from './reducers';
import { loadState, saveState } from './localstorage/localStorage';
import _ from 'lodash';

export const customStore = () => {
    const persistedState = loadState();
    const store = createStore(todoApp, persistedState);

    store.subscribe(_.throttle(() => {
        saveState({
            todos: store
                .getState()
                .todos,
        });
    }, 1000));

    return store;
};

