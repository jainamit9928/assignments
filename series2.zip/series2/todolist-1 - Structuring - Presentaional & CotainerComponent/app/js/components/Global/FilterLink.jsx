// conatiner component behaviour and data

import React from 'react';
import ReactDOM from 'react-dom';
import Link from './Link';
//import store from '../../store.js';

export default class FilterLink extends React.Component{
constructor(props){
super(props)
this.executeStore = props.store;
console.log("store in filterlink"+this.executeStore);
this.state = this.executeStore.getState();
}
componentDidMount(){
this.unsubscribe =this.executeStore.subscribe(() => this.forceUpdate())
}
componentWillUnmount() {
    this.unsubscribe();
}

render(){
    const props =this.props;
return (
<Link active ={props.filter === this.state.visibilityFilter } onClick ={() => {this.executeStore.dispatch({type:"SET_VISIBILITY_FILTER",filter:props.filter})}} > {this.props.children} </Link>


)


}


}