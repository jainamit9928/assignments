import React from 'react';
import ReactDOM from 'react-dom';
const Link = ({active,onClick,children}) => {
if(active){
    return <span>{children}</span>
}
return (
<a href="#" onClick = {(e) => { e.preventDefault();
onClick();
    
 } }>{children}
    
    </a>

)


}
export default Link;

// no props to send from top level component like visbility filter