let nextTodoId = 0;

const todo = (state, action) => {
    switch (action.type) {
        case 'ADD_TODO':
            return {
                id: nextTodoId++,
                text: action.text,
                completed: false
            }
        case 'TOGGLE_TODO':
            {
                if (state.id !== action.id) {
                    return state
                }

                return {
                    id: state.id,
                    text: state.text,
                    completed: !state.completed
                }

            }
        default:
            return state
    }
}

const todos = (state = [], action) => {
    switch (action.type) {
        case 'ADD_TODO':
            return [
                ...state,
                todo(undefined, action)
            ];
        case 'REMOVE_TODO':
            {
                let removedTodoArray = state.filter((todo, index) => todo.id != action.id);
                console.log(removedTodoArray);
                return removedTodoArray;

            }
        case 'TOGGLE_TODO':
            {

                return state.map((t, index) => todo(t, action))

            }
        default:
            return state;
    }

}

export default todos;