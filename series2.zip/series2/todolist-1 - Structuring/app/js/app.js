import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, IndexRoute, browserHistory } from 'react-router';
import TodoApp from './components/Global/TodoApp'
import store from './store.js'

let executeStore = store()
const render = () => ReactDOM.render(
  <TodoApp executeStore ={executeStore} {...executeStore.getState()}/>,
  document.getElementById('app') // eslint-disable-line
);
render();
executeStore.subscribe(render);
