import React from 'react';
import ReactDOM from 'react-dom';
const AddTodo = ({onAddTodo}) => {
 let input;
 return (
<div>
  <input type="text" ref={node => {
      input=node} 
      }/>
     
     <button onClick ={ () => {
        onAddTodo(input.value);
        input.value =""
       }
       
       }>Add Todo</button> 


</div>


 )


}

export default AddTodo;