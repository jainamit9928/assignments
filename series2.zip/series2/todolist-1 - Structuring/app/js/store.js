import { createStore } from 'redux'
import todoApp from './reducers'
const store = () => {
   let store = createStore(todoApp);
   console.log(store);
   return store;

}

export default store;