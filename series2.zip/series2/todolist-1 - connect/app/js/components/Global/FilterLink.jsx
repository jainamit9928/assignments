// conatiner component behaviour and data

import React from 'react';
import ReactDOM from 'react-dom';
import Link from './Link';
//import store from '../../store.js';

export default class FilterLink extends React.Component{
constructor(props){
super(props)
}
componentDidMount(){
    const {store} = this.context;
this.unsubscribe =store.subscribe(() => this.forceUpdate())
}
componentWillUnmount() {
    this.unsubscribe();
}

render(){
    const {store} = this.context;
return (
<Link active ={this.props.filter === store.getState().visibilityFilter } onClick ={() => {store.dispatch({type:"SET_VISIBILITY_FILTER",filter:this.props.filter})}} > {this.props.children} </Link>


)


}


}

FilterLink.contextTypes = {

    store :React.PropTypes.object
}