import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, IndexRoute, browserHistory } from 'react-router';
import TodoApp from './components/Global/TodoApp'
import store from './store.js'
import _ from 'lodash';
import '../css/main.less'
let executeStore = store()


let render = () => ReactDOM.render(
  <TodoApp executeStore ={executeStore} {...executeStore.getState()}/>,
  document.getElementById('app') 
);
render();
executeStore.subscribe(render);
