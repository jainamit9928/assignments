import React from 'react';
import ReactDOM from 'react-dom';
const FilterLink = (props) => {
if(props.filter === props.currentVisibiltyFilter){
    return <span>{props.children}</span>
}
return (
<a href="#" onClick = {(e) => {
    e.preventDefault();
    props.customStore.dispatch({type:"SET_VISIBILITY_FILTER",filter:props.filter})
    
 } }>{props.children}
    
    </a>

)


}
export default FilterLink;