import { createStore } from 'redux'
import todoApp from '../reducers'
const store = (todoApp) => {
   return createStore(todoApp);

}

export default store;