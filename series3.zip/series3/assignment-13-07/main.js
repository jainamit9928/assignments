var loginDetail;
(function Credentials() {
    loginDetail = {
        username: "jainamit",
        password: "password"
    }
})();

function submitForm() {

    var username = document.getElementById("username").value;
    var password = document.getElementById("inputPassword").value;
    if (username == loginDetail.username && password == loginDetail.password) {
        alert("Logeed In Successfully");
    }
    var remember = document.getElementById('remember');
    if (remember.checked) {
        serilazeObject(loginDetail);
    }
}





function serilazeObject(obj) {
    var serilizedObj = JSON.stringify(obj);
    setToLocalStorage(obj.password, serilizedObj);
}


function setToLocalStorage(key, obj) {
    try {
        localStorage.setItem(key, obj);
        alert("data saved");
    } catch (error) {

    }
}