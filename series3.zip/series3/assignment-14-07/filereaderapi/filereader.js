//setup drag and drop listenres
var dropArea;
(function() {
    // Setup the dnd listeners.
    dropArea = document.getElementById('drop_area');
    dropArea.addEventListener('dragover', handleDragOver, false);
    dropArea.addEventListener('drop', handleFileSelect, false);
})();

function handleFileSelect(e) {
    e.stopPropagation();
    e.preventDefault();
    var files = e.dataTransfer.files;
    var file = files[0];
    if (files && file) {

        var reader = new FileReader();
        var output = [];
        var image = document.createElement("img");

        reader.onload = function(event) {
            image.src = event.target.result;
            document.getElementById("result").append(image);
            var fd = new FormData();
            fd.append('fname', 'test.txt');
            fd.append('data', event.target.result);
            console.log(fd);
            $.ajax({
                type: 'POST',
                url: '',
                data: fd,
                processData: false,
                contentType: false
            }).done(function(data) {

                console.log(data);
            });
        };

        reader.readAsDataURL(file);

    }


}


function handleDragOver(evt) {
    evt.stopPropagation();
    evt.preventDefault();
    evt.dataTransfer.dropEffect = 'copy';
}