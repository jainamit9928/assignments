function partialRight(input) {
    var slice = Array.prototype.slice;
    var args = slice.call(arguments, 1);
    return function() {
        return input.apply(undefined, slice.call(arguments, 0).concat(args));
    }
}



function curry(f, n) {
    var slice = Array.prototype.slice;
    var args = slice.call(arguments, 0);
    if (typeof n !== 'number')
        args[1] = f.length;
    if (n === args.length - 2)
        return f.apply(undefined, args.slice(2));
    return function() {
        return curry.apply(undefined, args.concat(slice.call(arguments, 0)));
    };
}
Array.prototype.myReduce = function(fn,defaultValue){
  var self =this;
  var accumlator = defaultValue;
  console.log(self);
  self.forEach(function(value,index){
    if(accumlator == undefined){
      accumlator =value;
    }
    accumlator =fn.call(undefined,accumlator,value,index,self);
  })
  return accumlator;

}
var b = curry(function(a, b, c) { return a + b + c });
b(1)(2)(3);
