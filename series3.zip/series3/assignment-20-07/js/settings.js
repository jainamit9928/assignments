var setting = window.setting || {};

setting = (function() {
    var set = {};
    set.intialState = {};

    function splitPath(path) {
        return path.split("/");
    }

    function reducePathToObject(state, paths, value) {
        console.log(Object.getOwnPropertyNames(set.intialState).length);
        if (Object.keys(set.intialState).length === 0) {
            set.intialState = updateState(set.intialState, paths, value);
        } else {
            var state = updateState({}, paths, value);
            var obj = Object.assign({}, set.intialState, state);
            set.intialState = obj;
        }


    };

    function updateState(state, keys, val) {
        if (keys.length === 1) {
            state[keys[0]] = val;
        } else {
            var key = keys.shift();
            state[key] = updateState(typeof state[key] === 'undefined' ? {} : state[key], keys, val);
        }

        return state;
    };
    set.setSettings = function(path, value, option) {
        console.log(state);
        var pathArray = splitPath(path);
        var state = reducePathToObject(set.intialState, pathArray, value);
    }
    return set;
})();
setting.setSettings("a/b/c/d", 200, true);
console.log(setting.intialState);
setting.setSettings("a/b/c/e", 300, true);
console.log(setting.intialState);
setting.setSettings("a/b/c/d/f", 300, true);
console.log(setting.intialState);
setting.setSettings("a/b/c/d/e/f", 300, true);
console.log(setting.intialState);