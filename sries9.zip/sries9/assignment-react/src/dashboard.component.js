import React from 'react';
import {BrowserRouter as Router,Route,Link } from 'react-router-dom'
import InnerDashboard from './inner.component'
const Dashboard = ({match}) =>{
return(
<section>

    <div className="row">
        <div className="col-md-6">
           <Route exact path={match.url} render = { () => ( <h3>Please select a page</h3>) } />
            <ul>
                <li>
                <Link className ="btn btn-success" to={`${match.url}/details`} >
                Detail
                </Link>
                </li>
                <li>
                <Link className ="btn btn-success" to={`${match.url}/transactions`} >
               transactions
                </Link>
                </li>
               
        </ul>
            
           
             
            
        </div>
        <div className="col-md-6">
         <Route  path={`${match.url}/:paramId`} component={InnerDashboard} />
        </div>
     </div>

</section>
)
}


export default Dashboard