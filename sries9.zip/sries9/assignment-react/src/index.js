import React from 'react';
import ReactDOM from 'react-dom'
import Page from './page.component'
ReactDOM.render(
   <Page />
,document.getElementById("container")
    );
