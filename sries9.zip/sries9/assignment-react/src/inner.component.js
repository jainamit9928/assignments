import React from 'react';

const InnerDashboard = ({match}) =>{
let divStyle = {
  color:"green",
  
};

    return(
        <section>
           <h3 style={divStyle}>This a {match.params.paramId} Page</h3>
</section>
)
}
export default InnerDashboard