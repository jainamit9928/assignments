import React from 'react';
const Logo = (props) =>(
   
<div className="row panel">
<img src="../assets/images/logo.jpg" width="100" height="100" alt={props.title}/>
<h3>{props.title}</h3>
</div>
)
export default Logo;
