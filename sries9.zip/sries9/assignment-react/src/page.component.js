import React from 'react';
import ReactDOM from 'react-dom'
import {BrowserRouter as Router,Route,Link } from 'react-router-dom'
import Logo from './logo.component'
import Footer from './footer.component'
import Dashboard from './dashboard.component'
import Profile from './profile.component'
import MyHistory from './myhistory.component'

export default class Page extends React.Component{
constructor(props){
    super(props);
    this.divStyle={
        "background":"grey",
        "boxShadow":"10px 10px 10px white",
        "width":"100%",
        "height":"100%"

    }
}

render(){

   
    return(
        <Router>
  

 
        
           <div >
                <header className="container">
                <div className="col-md-6">
                    <Logo title ="Welcome to Saxo" />
                </div>
            
                <div className="col-md-6">
                    
                       <Menu />
                     
                </div>
                </header>
                <main className="container" style={this.divStyle}>
            <div className="col-md-12">
               <Route  path="/dashboard" component={Dashboard} />
                <Route  path="/myhistory" component={MyHistory} />
                <Route  path="/profile" component={Profile} />
            </div>
             </main>
                 <div className="container">
                        <Footer />
                </div>
           </div>
          
    
        </Router>
    )
}
}

const Menu = (props) => {
    return(
                    <nav>
                                 <ul>
                                     <li><Link to="/dashboard" >DashBoard</Link></li>
                                    <li><Link to="/profile">Profile</Link></li>
                                    <li><Link to="/myhistory" >My History</Link></li>
                                 </ul>
       
                        </nav>
    )
}