import React from 'react';
import {BrowserRouter as Router,Route,Link } from 'react-router-dom'
import InnerDashboard from './inner.component'
const Profile = ({match}) =>{
return(
<section>

    <div className="row">
        <div className="col-md-6">
           <Route exact path={match.url} render = { () => ( <h3>Please select a Page</h3>) } />
            <ul>
                <li>
                <Link className ="btn btn-success" to={`${match.url}/accountsummary`} >
                Account Summary
                </Link>
                </li>
                <li>
                <Link className ="btn btn-success" to={`${match.url}/statements`} >
              Statements
                </Link>
                </li>
               
        </ul>
            
          
             
            
        </div>
        <div className="col-md-6">
        
          <Route  path={`${match.url}/:paramId`} component={InnerDashboard} />
        </div>
     </div>

</section>
)
}

export default Profile