import _ from 'lodash';

export const getVisibleTodos = (todos, filter) => {
    switch (filter) {
        case 'SHOW_ALL':
            return todos;

        case 'SHOW_COMPLETED':
            return _.filter(todos, ['completed', true]);

        case 'SHOW_ACTIVE':
            return _.reject(todos, ['completed', true]);
    }
};

export const setVisibilityFilter = (filter) => {
    return {
        type: 'SET_VISIBILITY_FILTER', filter,
    };
};
