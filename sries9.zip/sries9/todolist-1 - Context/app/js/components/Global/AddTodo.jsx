import React from 'react';
import {connect} from 'react-redux';
import PropTypes from 'prop-types';

//presentaional component
const AddTodos = ({onAddClick}) => {
    let input;
    let divStyle ={
        "margin":"100px"
    }
    return (
        <div>
            <input type="text" ref={node => {
                input = node
            }}/>

            <button onClick= { () => { onAddClick(input.value); input.value = ""; } }>Add Todo</button>

        </div>

    )

}
AddTodos.propTypes = {
    onAddClick: PropTypes.func.isRequired
};

//creating container component
const AddTodo = connect(null, (dispatch) => {
    return {
        onAddClick: (text) => {
            dispatch({type: "ADD_TODO", text: text});

        }
    }

})(AddTodos)
export default AddTodo;